//
//  UIImage+Tone.h
//  vtell
//
//  Created by 孙旭让 on 2017/6/8.
//  Copyright © 2017年 sohu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Tone)

- (UIImage *)imageTone;

@end
