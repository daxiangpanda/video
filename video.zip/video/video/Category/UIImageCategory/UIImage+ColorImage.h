//
//  UIImage+ColorImage.h
//  vtell
//
//  Created by 孙旭让 on 2017/4/21.
//  Copyright © 2017年 sohu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (ColorImage)

+ (UIImage *)imageWithColor:(UIColor *)color;

@end
