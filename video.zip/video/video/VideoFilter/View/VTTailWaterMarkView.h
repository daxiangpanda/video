#import <UIKit/UIKit.h>

@interface VTTailWaterMarkView : UIView

@property (nonatomic,strong) NSString      *userName;
@property (nonatomic,assign) CGFloat       waterMarkAlpha;
@end
