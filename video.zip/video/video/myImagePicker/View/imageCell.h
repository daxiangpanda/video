//
//  imageCell.h
//  video
//
//  Created by 刘鑫忠 on 2017/9/20.
//  Copyright © 2017年 刘鑫忠. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface imageCell : UITableViewCell

@property(nonatomic, strong) UIImage*       videoImage;
@end
